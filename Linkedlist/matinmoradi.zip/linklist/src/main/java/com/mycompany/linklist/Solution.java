// linkedlist=  mohamad matin moradi "140011041039" 
// seyed mohamad reza mirshafie "140011041046"



package com.mycompany.linklist;
public class Solution {
public class Linklist {

     
        
    
    public static void main(String[] args) {
        
        
        
        
       Node poly2 = new Node(-5, 1);
        append(poly2, -5, 0);
        Node poly1;
        Node poly1 = new Node(5, 2);
        append(poly1, 4, 1);
        append(poly1, 2, 0); 
        Node sum = addPolynomial(poly1, poly2);
        
        
        
        
                for (Node ptr = sum; ptr != null; ptr = ptr.next) {
           
                System.out.print(ptr.coeff + "x^"
                             + ptr.pow);
                if (ptr.next != null)
                System.out.print(" + ");
        }
                System.out.println();
    }
 
   
    
    public static void append(Node head, int coeff,
                              int power)
    {
        Node new_node = new Node(coeff, power);
        while (head.next != null) {
        head = head.next;
        }
        head.next = new_node;
    }
 
    
   
        public static Node addPolynomial(Node p1, Node p2)
    {
        Node res = new Node(
            0, 0); 
        Node prev
            = res; 
        
        
                while (p1 != null && p2 != null) {
                if (p1.pow < p2.pow) {
                prev.next = p2;
                prev = p2;
                p2 = p2.next;
            }
                else if (p1.pow > p2.pow) {
                prev.next = p1;
                prev = p1;
                p1 = p1.next;
            }
                else {
                p1.coeff = p1.coeff + p2.coeff;
                prev.next = p1;
                prev = p1;
                p1 = p1.next;
                p2 = p2.next;
            }
        }
        
        
        if (p1 != null) {
            prev.next = p1;
        }
        else if (p2 != null) {
            prev.next = p2;
        }
        return res.next;
    }
}
 



    class Node {
    public int coeff;
    public int pow;
    public Node next;
 
    public Node(int c, int p)
    {
    this.coeff = c;
    this.pow = p;
    this.next = null;
    }
}}
  




